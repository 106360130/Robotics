function cos_result = cos_r(angle)
    %輸入為角度，但cos的計算是用徑度
    cos_result = cos(angle*(pi/180));
end