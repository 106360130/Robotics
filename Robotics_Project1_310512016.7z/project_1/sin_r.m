function sin_result = sin_r(angle)
    %輸入為角度，但sin的計算是用徑度
    sin_result = sin(angle*(pi/180));
end